﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Practical_8
{
    /// <summary>
    /// class for hello world string
    /// </summary>
    public class Helloworldtest
    {
        #region Properties
        /// <summary>
        /// hello world string
        /// </summary>
        /// <returns>hello world</returns>
        public string hello()
        {
            return "Hello World";
        }
        #endregion 
    }
}